# Data_Wrangling-WeRateDogs
### Introduction
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
In this project I used python and it's libraries to gather data from a variety of sources and in various formats to assess the data's quality and tidiness issues in the jupyter notebook found in this repository.
The wrangling process was documented in the Wrangle Report and Act Report also found in this repository.

# Project Steps Overview
- Gathering data
- Assessing data
- Cleaning data
- Storing data
- Analyzing and reporting data
- Reporting
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Packages used
- Pandas
- Numpy
- Requests
- Tweepy
- Json
